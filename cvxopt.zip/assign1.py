from cvxopt import matrix, solvers

c = matrix([ 0.0, 0.0 ])
G = matrix([[-1.0, 0.0, -1.0, 1.0, 1.0],[0.0, -1.0, -1.0, 1.0, 2.0]])
h = matrix([0.0, 0.0, 1.0, 2.0, 2.0])

sol=solvers.lp( c, G, h )

print( 'PRINT SOLUTION_1' )
print( sol )

print( sol['x'] )

c = matrix([ 2.0, 3.0 ])
G = matrix([[-1.0, 0.0, -1.0, 1.0, 1.0],[0.0, -1.0, -1.0, 1.0, 2.0]])
h = matrix([0.0, 0.0, 1.0, 2.0, 2.0])

sol = solvers.lp(c, G, h)

print( 'PRINT SOLUTION_2' )
print( sol )
print( sol['x'] )



c = matrix([ 2.0, 3.0 ])
G = matrix([[-1.0, 0.0, -1.0, 1.0, 1.0, -1.0],[0.0, -1.0, -1.0, 1.0, 2.0, 1.0]])
h = matrix([0.0, 0.0, 1.0, 2.0, 2.0, 1.0])

sol = solvers.lp(c, G, h)

print( 'PRINT SOLUTION_3' )
print( sol )
print( sol['x'] )

